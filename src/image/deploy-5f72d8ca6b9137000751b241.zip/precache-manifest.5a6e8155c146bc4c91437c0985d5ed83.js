self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9f23a3ecb1991cdff786b61d6b8a4cee",
    "url": "/index.html"
  },
  {
    "revision": "0d16584e5d7bb1a68004",
    "url": "/static/css/main.c7abe338.chunk.css"
  },
  {
    "revision": "0470884fe4fe32aedd61",
    "url": "/static/js/2.056e0171.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "/static/js/2.056e0171.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0d16584e5d7bb1a68004",
    "url": "/static/js/main.929bbac1.chunk.js"
  },
  {
    "revision": "aa021fda20e39141570e",
    "url": "/static/js/runtime-main.6592cab6.js"
  },
  {
    "revision": "37a75b54218416da18cdf1fa0650c569",
    "url": "/static/media/Background.37a75b54.jpg"
  },
  {
    "revision": "64a8478366d65e2d2dc054833fc124db",
    "url": "/static/media/Logo original RGB new.64a84783.svg"
  }
]);